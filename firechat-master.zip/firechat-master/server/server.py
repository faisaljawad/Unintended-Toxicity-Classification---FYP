from http.server import BaseHTTPRequestHandler, HTTPServer
import time
import json
import urllib.parse as urlparse
from urllib.parse import parse_qs
from preprocessing import preprocess_func

hostName = "localhost"
hostPort = 80

class prediction:
    def return_prediction(self):
        print("Prediction Function called!")
        return 0.9

class http_server:
    def __init__(self, p1):
        server = HTTPServer(('localhost', 80), MyServer)
        print(time.asctime(), "Server Starts - %s:%s" % (hostName, hostPort))
        server.p1 = p1
        server.serve_forever()

class MyServer(BaseHTTPRequestHandler):
    def do_GET(self):
        if (self.server.p1.return_prediction() < 0.5):
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(bytes("True", "utf-8"))
            url = self.path
            parse = urlparse.urlparse(url)
            msg = str(parse_qs(parse.query)['messageContent'])
            print("Class opened in true")
            print("Message string:",msg)
            msg = preprocess_func(msg)
            print("Preprocessed Message:", msg)
        else:
            self.send_response(201)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(bytes("False", "utf-8"))
            url = self.path
            parse = urlparse.urlparse(url)
            msg = str(parse_qs(parse.query)['messageContent'])
            print("Class opened in false")
            print("Message string:",msg)
            msg = preprocess_func(msg)
            print("Preprocessed Message:", msg)

class main:
    def __init__(self):
        self.p1 = prediction()
        self.server = http_server(self.p1)

if __name__ == '__main__':
    m = main()