from preprocessing import preprocess_func

input_str = "You are Fucking bitch"
new_str = preprocess_func(input_str)
print("Preprocessed Text:",new_str)
input_str = "I am not interested in W0rking with you"
new_str = preprocess_func(input_str)
print("Preprocessed Text:",new_str)